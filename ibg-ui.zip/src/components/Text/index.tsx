export { default as Text } from "./Text";
export type { TextProps } from "./types";
